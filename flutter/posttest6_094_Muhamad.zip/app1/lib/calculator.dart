import 'package:app1/about.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

//membuat class calculator app sebagai extend dari stateless widget
class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    Future<void> createOrderMessage() async {
      print(("width", MediaQuery.of(context).size.width));
      print(("height", MediaQuery.of(context).size.height));
    }

    createOrderMessage();
    return MaterialApp(
      title: 'Calculator App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const CalculatorScreen(),
    );
  }
}

// membuat class calculatorscreen sebagai extend dari statefulwidget
class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

// membuat class _CalculatorScreenState sebagai extend dari calculatorscreen yang di atas
class _CalculatorScreenState extends State<CalculatorScreen> {
  //membuat variabel di dalam class
  String _nilaiSementara = '';
  String _input = '';
  double? _nomor1;
  double? _nomor2;
  String? _operator = '';
  String _hasilAkhir = '';

  void _buttonPressed(String buttonText) {
    // if (_operator == '=') {
    //   if (buttonText == '+' ||
    //       buttonText == '-' ||
    //       buttonText == '*' ||
    //       buttonText == '/') {
    //     _operator = buttonText;
    //   }
    // } else
    if (buttonText == 'C') {
      _input = '';
      _hasilAkhir = '';
      _nilaiSementara = '';
      _nomor1 = null;
      _nomor2 = null;
      _operator = '';
    } else if (buttonText == '+' ||
        buttonText == '-' ||
        buttonText == '*' ||
        buttonText == '/') {
      if (_nomor1 == null) {
        if (_input == '') {
          _nomor1 = 0;
        } else {
          _nomor1 = double.parse(_input);
        }
        _nilaiSementara = '';
      } else {
        // if (_operator != null || _operator != '') {
        //   buttonText = '+';
        // }
        if (_input == '') {
          _nomor2 = 0;
        } else {
          _nomor2 = double.parse(_input);
        }
        double? result;
        switch (_operator) {
          case '+':
            result = _nomor1! + _nomor2!;
            break;
          case '-':
            result = _nomor1! - _nomor2!;
            break;
          case '*':
            result = _nomor1! * _nomor2!;
            break;
          case '/':
            result = _nomor1! / _nomor2!;
            break;
          default:
            result = _nomor1;
            break;
        }

        _nilaiSementara = result.toString();
        _hasilAkhir = _nilaiSementara;
        _nomor1 = result;
      }
      _operator = buttonText;
      _input = '';
    } else if (buttonText == '=') {
      if (_hasilAkhir == '' || _hasilAkhir == 'null') {
        _hasilAkhir = '0';
      }
      if (_nomor1 == null) {
        _nomor1 = double.parse(_hasilAkhir);
        _nilaiSementara = _hasilAkhir;
      } else {
        if (_input == '') {
          _nomor2 = 0;
        } else {
          _nomor2 = double.parse(_input);
        }
      }
      if (_operator == '+' ||
          _operator == '-' ||
          _operator == '*' ||
          _operator == '/') {
        double? result;
        switch (_operator) {
          case '+':
            result = _nomor1! + _nomor2!;
            break;
          case '-':
            result = _nomor1! - _nomor2!;
            break;
          case '*':
            result = _nomor1! * _nomor2!;
            break;
          case '/':
            result = _nomor1! / _nomor2!;
            break;
        }
        _nilaiSementara = result.toString();
        _hasilAkhir = _nilaiSementara;
        _input = '';
        // _nomor1 = null;
        _operator = '';
      }
    } else {
      if (_operator == "=") {
        // _input = '';
        // _hasilAkhir = '';
        _operator = '';
      }
      _input += buttonText;
    }
    //  _hasilAkhir = _input;
    // _nilaiSementara = 'Result: $_hasilAkhir';
    setState(() {});
  }

  // untuk text dari output

// membuat widget buildbutton untuk template button agar dapat di pakai terus menerus
  Widget _buildButton(
      String buttonText, double buttonHeight, double buttonWidth) {
    return Container(
      padding: const EdgeInsets.all(4),
      height: MediaQuery.of(context).size.height * 0.1 * buttonHeight,
      width: MediaQuery.of(context).size.height * 0.1 * buttonWidth,
      child: ElevatedButton(
        onPressed: () => _buttonPressed(buttonText),
        child: Text(
          buttonText,
          style: const TextStyle(fontSize: 24.0),
        ),
      ),
    );
  }

  //membuat jika about di tekan
  void _aboutPressed() {
    Navigator.of(context)
        .push(CupertinoPageRoute(builder: (BuildContext context) {
      return const aboutApp();
    }));
  }

  //template untuk build button
  Widget _buildAbout(String abouts, double buttonHeight, double buttonWidth) {
    return Container(
      padding: const EdgeInsets.all(4),
      height: MediaQuery.of(context).size.height * 0.1 * buttonHeight,
      width: MediaQuery.of(context).size.height * 0.1 * buttonWidth,
      color: Colors.white,
      child: ElevatedButton(
        onPressed: () => _aboutPressed(),
        child: Text(
          abouts,
          style: const TextStyle(fontSize: 12.0, color: Colors.white),
        ),
      ),
    );
  }

  // membuat page dari yang ingin di buat
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
      ),
      body: Column(
        children: <Widget>[
          Container(
              alignment: Alignment.topRight,
              // color: Colors.black,
              // margin: EdgeInsets.symmetric(vertical: 150),
              child: Column(
                  // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Row(
                      children: <Widget>[_buildAbout("about", 0.5, 1)],
                    ),
                  ])),

          Container(
            alignment: Alignment.topLeft,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Text(
              _operator!,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            alignment: Alignment.topLeft,
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              _input,
              style:
                  const TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            alignment: Alignment.bottomLeft,
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            child: Text(
              'Result : $_hasilAkhir',
              style:
                  const TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
            ),
          ),
          const Expanded(
            child: Divider(),
          ),

          // child
          // Container(

          // ),
          Container(
            alignment: Alignment.center,
            // color: Colors.black,
            // margin: EdgeInsets.symmetric(vertical: 150),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    _buildButton('7', 1, 1),
                    _buildButton('8', 1, 1),
                    _buildButton('9', 1, 1),
                    _buildButton('/', 1, 1),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    _buildButton('4', 1, 1),
                    _buildButton('5', 1, 1),
                    _buildButton('6', 1, 1),
                    _buildButton('*', 1, 1),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    _buildButton('1', 1, 1),
                    _buildButton('2', 1, 1),
                    _buildButton('3', 1, 1),
                    _buildButton('-', 1, 1),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    _buildButton('C', 1, 1),
                    _buildButton('0', 1, 1),
                    _buildButton('=', 1, 1),
                    _buildButton('+', 1, 1),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
