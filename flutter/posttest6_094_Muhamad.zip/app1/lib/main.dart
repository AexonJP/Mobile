import 'dart:io';
import 'package:app1/home.dart';

import 'package:flutter/material.dart';
import 'package:window_size/window_size.dart';

void main() {
  double maxWidth = 1720;
  double minWidth = 300;
  double minHeight = 500;
  double maxHeight = 1500;

  WidgetsFlutterBinding.ensureInitialized();

  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    setWindowTitle('calculator');

    setWindowMaxSize(Size(maxWidth, maxHeight));
    setWindowMinSize(Size(minWidth, minHeight));
  }
  // runApp(const CalculatorApp());
  runApp(const homeApp());
}
