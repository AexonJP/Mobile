import 'package:app1/calculator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

//membuat class calculator app sebagai extend dari stateless widget
class aboutApp extends StatelessWidget {
  const aboutApp({super.key});

  @override
  Widget build(BuildContext context) {
    Future<void> createOrderMessage() async {
      print(("width", MediaQuery.of(context).size.width));
      print(("height", MediaQuery.of(context).size.height));
    }

    createOrderMessage();
    return MaterialApp(
      title: 'Calculator App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const aboutScreen(),
    );
  }
}

// membuat class aboutScreen sebagai extend dari statefulwidget
class aboutScreen extends StatefulWidget {
  const aboutScreen({super.key});

  @override
  _aboutScreenState createState() => _aboutScreenState();
}

// membuat class _aboutScreenState sebagai extend dari aboutScreen yang di atas
class _aboutScreenState extends State<aboutScreen> {
  void _buttonPressed(String buttonText) {
    Navigator.of(context)
        .push(CupertinoPageRoute(builder: (BuildContext context) {
      return CalculatorApp();
    }));
  }

  //membuat button yang dapat di gunaakn berkali-kali
  Widget _buildButton(
      String buttonText, double buttonHeight, double buttonWidth) {
    return Container(
      padding: const EdgeInsets.all(4),
      height: MediaQuery.of(context).size.height * 0.1 * buttonHeight,
      width: MediaQuery.of(context).size.height * 0.1 * buttonWidth,
      child: ElevatedButton(
        onPressed: () => _buttonPressed(buttonText),
        child: Text(
          buttonText,
          style: const TextStyle(fontSize: 12.0),
        ),
      ),
    );
  }

  // membuat bentuk dari about
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                child:
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    child: Row(children: [Text("made by abdullah")]),
                  ),
                ]),
              ),
              Container(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [_buildButton('back', 1, 1)],
                        ),
                      )
                    ]),
              )
            ]),
          )
        ],
      ),
    );
  }
}
