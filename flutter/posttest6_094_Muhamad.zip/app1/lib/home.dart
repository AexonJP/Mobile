import 'package:app1/calculator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

//membuat class calculator app sebagai extend dari stateless widget
class homeApp extends StatelessWidget {
  const homeApp({super.key});

  @override
  Widget build(BuildContext context) {
    Future<void> createOrderMessage() async {
      print(("width", MediaQuery.of(context).size.width));
      print(("height", MediaQuery.of(context).size.height));
    }

    createOrderMessage();
    return MaterialApp(
      title: 'Calculator App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const homeScreen(),
    );
  }
}

// membuat class homeScreen sebagai extend dari statefulwidget
class homeScreen extends StatefulWidget {
  const homeScreen({super.key});

  @override
  _homeScreenState createState() => _homeScreenState();
}

// membuat class _homeScreenState sebagai extend dari homeScreen yang di atas
//dan mengarahkan ke callculator app
class _homeScreenState extends State<homeScreen> {
  void _buttonPressed(String buttonText) {
    Navigator.of(context)
        .push(CupertinoPageRoute(builder: (BuildContext context) {
      return CalculatorApp();
    }));
  }

  Widget _buildButton(
      String buttonText, double buttonHeight, double buttonWidth) {
    return Container(
      padding: const EdgeInsets.all(4),
      height: MediaQuery.of(context).size.height * 0.1 * buttonHeight,
      width: MediaQuery.of(context).size.height * 0.1 * buttonWidth,
      child: ElevatedButton(
        onPressed: () => _buttonPressed(buttonText),
        child: Text(
          buttonText,
          style: const TextStyle(fontSize: 12.0),
        ),
      ),
    );
  }

  // isi yang ada di page
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            child:
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                child:
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    child: Row(children: [Text("Tekan untuk masuk ke dalam")]),
                  ),
                ]),
              ),
              Container(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [_buildButton('Start', 1, 1)],
                        ),
                      )
                    ]),
              )
            ]),
          )
        ],
      ),
    );
  }
}
